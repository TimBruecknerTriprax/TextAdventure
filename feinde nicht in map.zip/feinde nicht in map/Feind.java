
public class Feind extends Mensch
{

    public Feind()
    {
      super.pName = "Lappen";
      super.pLeben = 100;
      super.pAngriff = 50;
      super.pGeschwindigkeit= 10;
    }


}
