
public class Essen extends Gegenstand
{

    public Essen()
    {
        super.pSättigung = 5;
    }
}
