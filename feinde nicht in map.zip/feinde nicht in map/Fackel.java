
public class Fackel extends Gegenstand
{
    public Fackel()
    {
        super.pBrenndauer = 10;
    }
}
