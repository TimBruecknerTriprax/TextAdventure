
public class Heilblatt extends Gegenstand
{

    public Heilblatt()
    {
       
    }

  
}
