
public class Schwert extends Gegenstand
{
    public Schwert()
    {
        super.pSchaden = 50;
    }
}
