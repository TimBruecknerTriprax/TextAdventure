
public class Boxer extends Hauptcharakter
{
    
    public Boxer()
    {
      super.pName= "Unbekannter";
      
      //super.pErfahrung = 0;
      //super.pCooldown = 0;
      super.pLeben = 100;
      super.pIntelligenz = 50;
      super.pAngriff = 50;
      super.pRüstung = 0;
      super.pGeschwindigkeit= 50;
      super.pAusdauer = 10;

    }
    
}
