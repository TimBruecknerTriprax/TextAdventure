
/**
 * Die Klasse Mensch ist die Hauptklasse aller Charaktere mit ausnahme von Feinden.
 * 
 * @author (Max, Noah, Tim) 
 * @version (0.0.1 04.09.2017)
 */
public class Mensch
{
    private String Name;
    private int Erfahrung;
    private int Leben;
    private int Tragkraft;
    private int Intelligenz;
    private int Angriff;
    private int Rüstung;
    private int Geschwindigkeit;
    private int Ausdauer;
   
    public Mensch()
    {
      Name = "Unbekannter";
      Erfahrung = 0;
      Leben = 100;
      Tragkraft = 15;
      Intelligenz = 50;
      Angriff = 50;
      Rüstung = 0;
      Geschwindigkeit= 50;
      Ausdauer = 10;
    }

    private void gehen()
    {
       Erfahrung = Erfahrung +1;
  
    }
    
     private void essen()
    {
           Erfahrung = Erfahrung +1;
 
    }
    
     private void reden()
    {
           Erfahrung = Erfahrung +1;

    }
    
     private void kämpfen()
    {
           Erfahrung = Erfahrung +1;
   
    }
}
