import java.util.*;

/**
 * Hauptspiele Methode (Räume, Befehle)
 * @author (Max, Noah, Tim) 
 * @version (0.0.1 04.09.2017)
 */

public class Game 
{
    private Parser parser;
    private Room currentRoom;
    private static int currentHours, currentMinutes, currentSeconds;
    private static int startHours, startMinutes, startSeconds;
    private java.util.Date now;        
    /**
     * Initialisierung des Spiels und der Map.
     * Erstellung des Parsers (überprüft die Eingabe mit Command).
     */
    public Game() 
    {
        createRooms();
        parser = new Parser();
        now = new java.util.Date();
        startHours = now.getHours();
        startMinutes = now.getMinutes(); 
        startSeconds = now.getSeconds(); 
    }

    /**
     * Erstellt die Räume und verbindet sie.
     */
    private void createRooms()
    {
        Room outside, theater, pub, lab, office;
      
        // erstellt die Räume + Beschreibung
        Bunker1 = new Room("");
        Bunker2 = new Room("");
        Bunker3 = new Room("");
        
        Weg1Block1 = new Room("");
        Weg1Block2 = new Room("");
        Weg1Block3 = new Room("");
        
        Weg2Block1 = new Room("");
        Weg2Block2 = new Room("");
        Weg2Block3 = new Room("");
        Weg2Block4 = new Room("");
        Weg2Block5 = new Room("");
        
        Weg3Block1 = new Room("");
        Weg3Block2 = new Room("");
        Weg3Block3 = new Room("");
        Weg3Block4 = new Room("");
        Weg3Block5 = new Room("");
        Weg3Block6 = new Room("");
        
        Weg4Block1 = new Room("");
        Weg4Block2 = new Room("");
        Weg4Block3 = new Room("");
        Weg4Block4 = new Room("");
        Weg4Block5 = new Room("");
        
        Weg5Block1 = new Room("");
        Weg5Block2 = new Room("");
        Weg5Block3 = new Room("");
        Weg5Block4 = new Room("");
        Weg5Block5 = new Room("");
        Weg5Block6 = new Room("");
        Weg5Block7 = new Room("");
        Weg5Block8 = new Room("");
        Weg5Block9 = new Room("");
        
        Weg6Block1 = new Room("");
        Weg6Block2 = new Room("");
        
        Weg7Block1 = new Room("");
        Weg7Block2 = new Room("");
        Weg7Block3 = new Room("");
        Weg7Block4 = new Room("");
        Weg7Block5 = new Room("");
        Weg7Block6 = new Room("");
        
        Weg8Block1 = new Room("");
        Weg8Block2 = new Room("");
        Weg8Block3 = new Room("");
        Weg8Block4 = new Room("");
        Weg8Block5 = new Room("");
        
        Weg9Block1 = new Room("");
        Weg9Block2 = new Room("");
        Weg9Block3 = new Room("");
        Weg9Block4 = new Room("");
        Weg9Block5 = new Room("");
        
        Weg10Block1 = new Room("");
        Weg10Block2 = new Room("");
        Weg10Block3 = new Room("");
        
        Weg11Block1 = new Room("");
        Weg11Block2 = new Room("");
        Weg11Block3 = new Room("");
        Weg11Block4 = new Room("");
        Weg11Block5 = new Room("");
        Weg11Block6 = new Room("");
        
        
        Weg12Block1 = new Room("");
        Weg12Block2 = new Room("");
        Weg12Block3 = new Room("");
        Weg12Block4 = new Room("");
        Weg12Block5 = new Room("");
        Weg12Block6 = new Room("");
        
        Weg13Block1 = new Room("");
        Weg13Block2 = new Room("");
        Weg13Block3 = new Room("");
        Weg13Block4 = new Room("");
        Weg13Block5 = new Room("");
        Weg13Block6 = new Room("");
        Weg13Block7 = new Room("");
        Weg13Block8 = new Room("");
        
        Weg14Block1 = new Room("");
        Weg14Block2 = new Room("");
        Weg14Block3 = new Room("");
        
        Weg15Block1 = new Room("");
        Weg15Block2 = new Room("");
        
        Weg16Block1 = new Room("");
        Weg16Block2 = new Room("");
        Weg16Block3 = new Room("");
        Weg16Block4 = new Room("");
        Weg16Block5 = new Room("");
        Weg16Block6 = new Room("");
        Weg16Block7 = new Room("");
        
        Weg17Block1 = new Room("");
        Weg17Block2 = new Room("");
        Weg17Block3 = new Room("");
        
        Weg18Block1 = new Room("");
        Weg18Block2 = new Room("");
        Weg18Block3 = new Room("");
        Weg18Block4 = new Room("");
        Weg18Block5 = new Room("");
        Weg18Block6 = new Room("");
        Weg18Block7 = new Room("");
        
        Weg19Block1 = new Room("");
        Weg19Block2 = new Room("");
        
        Weg20Block1 = new Room("");
        Weg20Block2 = new Room("");
        
        Weg21Block1 = new Room("");
        Weg21Block2 = new Room("");
        
        Weg22Block1 = new Room("");
        Weg22Block2 = new Room("");
        
        Weg23Block1 = new Room("");
        Weg23Block2 = new Room("");
        Weg23Block3 = new Room("");
        Weg23Block4 = new Room("");
        Weg23Block5 = new Room("");
        
        Weg24Block1 = new Room("");
        Weg24Block2 = new Room("");
        Weg24Block3 = new Room("");
        
        Weg25Block1 = new Room("");
        Weg25Block2 = new Room("");
        Weg25Block3 = new Room("");
        
        Weg26Block1 = new Room("");
        Weg26Block2 = new Room("");
        Weg26Block3 = new Room("");
        Weg26Block4 = new Room("");
        
        Weg27Block1 = new Room("");
        Weg27Block2 = new Room("");
        Weg27Block3 = new Room("");
        Weg27Block4 = new Room("");
        
        Weg28Block1 = new Room("");
        Weg28Block2 = new Room("");
        
        
        
        outside = new Room("outside the main entrance of the university");
        theater = new Room("in a lecture theater");
        pub = new Room("in the campus pub");
        lab = new Room("in a computing lab");
        office = new Room("in the computing admin office");
        
        // Verbindet die Räume untereinander (nördlich,östlich,südlich,westlich) null = kein Ausgang
        
        
        
        
        
        
        Bunker1 = new Room("");
        Bunker2 = new Room("");
        Bunker3 = new Room("");
        
        Weg1Block1 = new Room("");
        Weg1Block2 = new Room("");
        Weg1Block3 = new Room("");
        
        Weg2Block1 = new Room("");
        Weg2Block2 = new Room("");
        Weg2Block3 = new Room("");
        Weg2Block4 = new Room("");
        Weg2Block5 = new Room("");
        
        Weg3Block1 = new Room("");
        Weg3Block2 = new Room("");
        Weg3Block3 = new Room("");
        Weg3Block4 = new Room("");
        Weg3Block5 = new Room("");
        Weg3Block6 = new Room("");
        
        Weg4Block1 = new Room("");
        Weg4Block2 = new Room("");
        Weg4Block3 = new Room("");
        Weg4Block4 = new Room("");
        Weg4Block5 = new Room("");
        
        Weg5Block1 = new Room("");
        Weg5Block2 = new Room("");
        Weg5Block3 = new Room("");
        Weg5Block4 = new Room("");
        Weg5Block5 = new Room("");
        Weg5Block6 = new Room("");
        Weg5Block7 = new Room("");
        Weg5Block8 = new Room("");
        Weg5Block9 = new Room("");
        
        Weg6Block1 = new Room("");
        Weg6Block2 = new Room("");
        
        Weg7Block1 = new Room("");
        Weg7Block2 = new Room("");
        Weg7Block3 = new Room("");
        Weg7Block4 = new Room("");
        Weg7Block5 = new Room("");
        Weg7Block6 = new Room("");
        
        Weg8Block1 = new Room("");
        Weg8Block2 = new Room("");
        Weg8Block3 = new Room("");
        Weg8Block4 = new Room("");
        Weg8Block5 = new Room("");
        
        Weg9Block1 = new Room("");
        Weg9Block2 = new Room("");
        Weg9Block3 = new Room("");
        Weg9Block4 = new Room("");
        Weg9Block5 = new Room("");
        
        Weg10Block1 = new Room("");
        Weg10Block2 = new Room("");
        Weg10Block3 = new Room("");
        
        Weg11Block1 = new Room("");
        Weg11Block2 = new Room("");
        Weg11Block3 = new Room("");
        Weg11Block4 = new Room("");
        Weg11Block5 = new Room("");
        Weg11Block6 = new Room("");
        
        
        Weg12Block1 = new Room("");
        Weg12Block2 = new Room("");
        Weg12Block3 = new Room("");
        Weg12Block4 = new Room("");
        Weg12Block5 = new Room("");
        Weg12Block6 = new Room("");
        
        Weg13Block1
        Weg13Block2
        Weg13Block3
        Weg13Block4
        Weg13Block5
        Weg13Block6
        Weg13Block7
        Weg13Block8
        
        Weg14Block1
        Weg14Block2
        Weg14Block3
        
        Weg15Block1
        Weg15Block2
        
        Weg16Block1
        Weg16Block2
        Weg16Block3
        Weg16Block4
        Weg16Block5
        Weg16Block6
        Weg16Block7
        
        Weg17Block1
        Weg17Block2
        Weg17Block3
        
        Weg18Block1
        Weg18Block2
        Weg18Block3
        Weg18Block4
        Weg18Block5
        Weg18Block6
        Weg18Block7
        
        Weg19Block1
        Weg19Block2
        
        Weg20Block1
        Weg20Block2
        
        Weg21Block1
        Weg21Block2
        
        Weg22Block1
        Weg22Block2
        
        Weg23Block1
        Weg23Block2
        Weg23Block3
        Weg23Block4
        Weg23Block5
        
        Weg24Block1
        Weg24Block2
        Weg24Block3
        
        Weg25Block1
        Weg25Block2
        Weg25Block3
        
        Weg26Block1
        Weg26Block2
        Weg26Block3
        Weg26Block4
        
        Weg27Block1
        Weg27Block2
        Weg27Block3
        Weg27Block4
        
        Weg28Block1
        Weg28Block2
        
        
        
        outside.setExits(null, theater, lab, pub);
        theater.setExits(null, null, null, outside);
        pub.setExits(null, outside, null, null);
        lab.setExits(outside, office, null, null);
        office.setExits(null, null, null, lab);

        currentRoom = outside;  //Anfangsraum
    }
   
    public static void main(String[] args) {
     Game newGame = new Game();
     newGame.play();       
        
    }
    
    /**
     *  Standard Spiel Verfahren. Wiederholt sich bis das Spiel beendet wird.
     *  Ruft den Parser auf und vergleicht die Commands.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing.  Good bye.");
        System.exit(0);
    }

    public static String getTime() {
        Date now2 = new java.util.Date();
        //currentHours = now2.getHours();
        currentMinutes = now2.getMinutes();
        //currentSeconds = now2.getSeconds(); 
        String timePlayed = (currentMinutes - startMinutes) + " Minutes.";
        return timePlayed;
        
    }
    
    /**
     * Startmeldung
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Willkommen im Jahre 2050!");
        System.out.println("Schau dich um und versuche zu überleben..");
        System.out.println("Schreibe 'hilfe' wenn du welche brauchst.");
        System.out.println();
        System.out.println("Du befindest dich gerade " + currentRoom.getDescription());
        System.out.print("Ausgänge: ");
        if(currentRoom.northExit != null) {
            System.out.print("nördlich ");
        }
        if(currentRoom.eastExit != null) {
            System.out.print("östlich ");
        }
        if(currentRoom.southExit != null) {
            System.out.print("südlich ");
        }
        if(currentRoom.westExit != null) {
            System.out.print("westlich ");
        }
        System.out.println();
    }

    /**
     * führt den Befehl aus. Hier werden die Befehle erstellt und müssen später in Command eingetragen werden. (Auch in Hilfe)
     * @param command The command to be processed.
     * @return wantToQuit wird solange wiederholt bis sich wantToQuit auf true ändert
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("Mhm, das funktioniert nicht...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("hilfe")) {
            printHelp();
        }
        else if (commandWord.equals("gehe")) {
            goRoom(command);
        }
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }

        return wantToQuit;
    }

    /**
     * Hilfestellung zum Spiel
     * Erstellt eine Naricht + die definierten Befehle
     */
    private void printHelp() 
    {
        System.out.println("Alles ist verlassen und zerstört...");
        System.out.println("Du solltest deinen Quest Log benutzen, schreibe dafür 'show quests'.");
        System.out.println();
        System.out.println("Die Befehle lauten:");
        System.out.println("   gehe quit hilfe");
    }

    /** 
     * Es wird versucht in eine Richtung zu gehen.
     * Wenn es einen Ausgang gibt wird in den Raum gewechselt.
     * Wenn nicht gibt es eine Fehlermeldung.
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // Wenn das zweite Wort nach 'gehe' fehlt kommt diese Meldung...
            System.out.println("Wohin soll ich gehen?");
            return;
        }

        String direction = command.getSecondWord();

        // Es wird versucht in den nächsten Raum zu gehen
        Room nextRoom = null;
        if(direction.equals("nördlich")) {
            nextRoom = currentRoom.northExit;
        }
        if(direction.equals("östlich")) {
            nextRoom = currentRoom.eastExit;
        }
        if(direction.equals("südlich")) {
            nextRoom = currentRoom.southExit;
        }
        if(direction.equals("westlich")) {
            nextRoom = currentRoom.westExit;
        }

        if (nextRoom == null) {
            System.out.println("Da geht es nicht weiter!");
        }
        else {
            currentRoom = nextRoom;
            System.out.println("Du bist " + currentRoom.getDescription());
            System.out.print("Wege: ");
            if(currentRoom.northExit != null) {
                System.out.print("nördlich ");
            }
            if(currentRoom.eastExit != null) {
                System.out.print("östlich ");
            }
            if(currentRoom.southExit != null) {
                System.out.print("südlich ");
            }
            if(currentRoom.westExit != null) {
                System.out.print("westlich ");
            }
            System.out.println();
            System.out.println("Du spielst schon seit " + getTime());
        }
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
}
