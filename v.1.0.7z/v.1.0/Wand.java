
public class Wand extends Gegenstand
{

   
    public Wand()
    {
        
    }

   
}
