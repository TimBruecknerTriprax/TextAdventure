
public class Feind extends Mensch
{

    public Feind()
    {
      super.pName = "Lappen";
      //super.pErfahrung = 0;
      //super.pCooldown = 0;
      super.pLeben = 100;
      super.pAngriff = 50;
      super.pRüstung = 0;
      super.pGeschwindigkeit= 10;
      super.pAusdauer = 10;
      super.pHunger = 0;
      super.pDurst = 0;
    }


}
