
public class Trinken extends Gegenstand
{
    public Trinken()
    {
        super.pDurstlöscher = 5;
    }
}
