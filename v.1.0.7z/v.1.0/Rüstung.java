
public class Rüstung extends Gegenstand
{
    public Rüstung()
    {
       super.pRüstungswert = 50;
    }

}
