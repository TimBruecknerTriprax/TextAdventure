
public class Verband extends Gegenstand
{
    

    
    public Verband()
    {
        
    }

   
    public int nehmen(int pHP)
    {
       // (set hp)-> etwas höher);
        System.out.println ("Dir geht es gleich viel Besser.");
        return pHP;
    }
}
