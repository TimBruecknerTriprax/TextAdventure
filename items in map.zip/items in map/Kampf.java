
import java.util.*;
import java.util.Scanner;
public class Kampf
{


    private Parser BattleParser;
    String pBattleEingabe;
    Scanner b = new Scanner(System.in);
    
    Feind Monster = new Feind();
    Schmied Charakter = new Schmied();
    
    String pNameFeind;
    String pNameCharakter;
    
    int pGeschwindigkeitCharakter;
    int pGeschwindigkeitFeind;
    
    double pLebenCharakter;
    double pLebenFeind;
    
    double pAngriffCharakter;
    double pAngriffFeind;
    
    public Kampf()
    {
     pNameFeind = Monster.getName();
     pNameCharakter = Charakter.getName();
     pGeschwindigkeitCharakter = Charakter.getGeschwindigkeit();
     pGeschwindigkeitFeind = Monster.getGeschwindigkeit();
     pLebenCharakter = Charakter.getLeben();
     pLebenFeind = Monster.getLeben();
     pAngriffCharakter = Charakter.getAngriff();
     pAngriffFeind = Monster.getAngriff();
   
  }   
  
  public void StartKampf(){
     System.out.println(pNameFeind+" verwickelt dich in einen Kampf!");
     System.out.println("Möchtest du 'kämpfen' oder 'fliehen'?");
     
     pBattleEingabe = b.next();
     
     if(pBattleEingabe.equals("kämpfen")){
         Kampfmodus();}
     else if(pBattleEingabe.equals("fliehen")){
        if(pGeschwindigkeitCharakter>pGeschwindigkeitFeind){
            if(pGeschwindigkeitCharakter*(Math.random()*10)>100){
                System.out.println("Du bist vor"+pNameFeind+"geflohen!");
             
             }
            } 
        else{Kampfmodus();}
    }
    else{System.out.println("Gib eine gültige Option ein!");
        StartKampf();
    }
    }
  private void Kampfmodus(){
   while(pLebenCharakter>0||pLebenFeind>0){
                        
      if(pGeschwindigkeitCharakter>pGeschwindigkeitFeind){Angriff();
        System.out.println("Du fügst"+pNameFeind+pAngriffCharakter+"Schaden zu.");
        }
      else{Angriff();
       System.out.println( pNameFeind+"fügt"+pNameCharakter+pAngriffFeind+"Schaden zu.");
        }
      if(pGeschwindigkeitCharakter>pGeschwindigkeitFeind){Angriff();
        System.out.println( pNameFeind+"fügt"+pNameCharakter+pAngriffFeind+"Schaden zu.");
      }
      else{Angriff();
        System.out.println("Du fügst"+pNameFeind+pAngriffCharakter+"Schaden zu.");
      }
            
      System.out.println("Du hast noch"+pLebenCharakter+"Leben!");
      System.out.println(pNameFeind+" hat noch"+pLebenFeind+"Leben!");
    }
   }
    
   private void Angriff(){
    System.out.println("Wie willst du angreifen: mit 'Tritt','Seitenhieb','Hieb von Oben'?");
    pBattleEingabe = b.next();
    if(pBattleEingabe.equals("Tritt")){
        System.out.println("Du trittst"+pNameFeind+"!");
        pLebenFeind = pLebenFeind-(pAngriffCharakter*0.5);
    }
        
    else if(pBattleEingabe.equals("Seitenhieb")){
       if( Math.random()*10>7){
          System.out.println("Du schlägst"+pNameFeind+"!");
         pLebenFeind = pLebenFeind-(pAngriffCharakter*0.75);
        }     
    }
    else if (pBattleEingabe.equals("Hieb von Oben")){
        if( Math.random()*10>5){
          System.out.println("Du zerschmetterst"+pNameFeind+"!");
         pLebenFeind = pLebenFeind-(pAngriffCharakter*1);
        } 
    }
    else{System.out.println("Das kannst du noch nicht! Vielleicht solltest du ein Dojo besuchen!");
         Angriff();
    }
   }
}
