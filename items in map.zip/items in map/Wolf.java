public class Wolf extends Feind
{

    public Wolf()
    {
      super.pName = "mutierter Wolf";
      super.pLeben = 50;
      super.pAngriff = 40;
      super.pGeschwindigkeit= 40;
    }


}