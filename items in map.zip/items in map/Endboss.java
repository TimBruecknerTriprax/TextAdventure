public class Endboss extends Feind
{

    public Endboss()
    {
      super.pName = "??????????";
      super.pLeben = 400;
      super.pAngriff = 50;
      super.pGeschwindigkeit= 70;
    }


}