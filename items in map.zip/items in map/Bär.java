public class Bär extends Feind
{

    public Bär()
    {
      super.pName = "mutierter Bär";
      super.pLeben = 200;
      super.pAngriff = 10;
      super.pGeschwindigkeit= 20;
    }


}