
public class Schuhe extends Gegenstand
{
    public Schuhe()
    {
        super.pSchnelligkeit = 5;
    }
}
