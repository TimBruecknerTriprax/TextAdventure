public class Fisch extends Feind
{

    public Fisch()
    {
      super.pName = "mutierter Fisch";
      super.pLeben = 60;
      super.pAngriff = 40;
      super.pGeschwindigkeit= 60;
    }


}