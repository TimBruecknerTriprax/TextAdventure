public class Fisch extends Feind
{

    public Fisch()
    {
      super.pName = "mutierter Fisch";
      super.pLeben = 30;
      super.pAngriff = 40;
      super.pGeschwindigkeit= 100;
    }


}