public class Baer extends Feind
{

    public Baer()
    {
      super.pName = "mutierter Bär";
      super.pLeben = 200;
      super.pAngriff = 10;
      super.pGeschwindigkeit= 20;
    }


}