
public class Ruestung extends Gegenstand
{
    public Ruestung()
    {
       super.pRüstungswert = 50;
    }

}
