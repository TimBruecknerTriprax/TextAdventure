public class Mann extends Feind
{

    public Mann()
    {
      super.pName = "herumstreunender Mann";
      super.pLeben = 100;
      super.pAngriff = 20;
      super.pGeschwindigkeit= 50;
    }


}